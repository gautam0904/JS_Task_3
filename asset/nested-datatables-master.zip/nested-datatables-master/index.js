import TableHierarchy from './src/script/NestedTables'
export {TableHierarchy};
